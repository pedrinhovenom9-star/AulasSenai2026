//Importar o Model do Genero
const Genero = require('../model/generoModel')

//Criar um objeto do Controller com os atributos
const generoController = {
    //Lógica da reqisição de cadastro
    cadastrar: async (req, res) => {
        //Recuperar o nome da requisição
        const {nome} = req.body;
        //Validar o valor do nome 
        if (!nome || nome .length < 3){
            //Código 400 - usuário valor errado
            return res.status(400).json({
                "erro": "Nome precisa de ao menos 3 caracteres"
            })
                
        }
        //Se passar pelo if então o nome está ok
        try{
            /**Chamart o atributo / função cadastrar do Model
             * O cadastrar do Model retorna o ID da linha
             */
            const idGenero = await Genero.cadastrar(nome);
            /** Exibir como resposta o ID gerado e nome */
            return res.status(200).json({
                "id": idGenero, "nome": nome
            })
        }catch(error){
            /** Erro 500  Erro do servidor */
            return res.status(500).json({
                "erro": "Erro ao cadastrar"
            })
        }
    },
    listarTodos: async(req, res) => {
        try{
            const resultado = await Genero.buscarTodos();
            return res.status(200).json(resultado);
        }catch(error){ return res.status(500).json({
            "erro": "erro ao buscar gêneros"
        })
        }

    }
}

module.exports = generoController;
